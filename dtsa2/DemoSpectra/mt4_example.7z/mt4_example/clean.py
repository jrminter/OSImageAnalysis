# Script name:  clean.py
# Author:       Nicholas W. M. Ritchie
# Date:		    18-Oct-2011
# Description:  A script for reversing the operations performed in 'config.py' which is associated with the Microscopy Today 
#				article 'Standards-based Quantification in DTSA-II - Part II'.
import com.thoughtworks.xstream as xs
import gov.nist.microanalysis.EPQLibrary.Detector as det
import javax.swing as jxsw

def showMessage(msg):
	jxsw.JOptionPane.showMessageDialog(MainFrame,msg,"Adding detector",jxsw.JOptionPane.INFORMATION_MESSAGE)

try:
	det = Database.findDetector("Detector 0 - Medium")
	if det:
		di=Database.findDetector(det.getDetectorProperties())
		Database.deleteDetector(di)
	showMessage("Please restart DTSA-II and restore your 'Default Detector' to complete this operation.")
except jl.Throwable, th:
	showMessage("There was an error deleting %s\n%s" % (det,th))
